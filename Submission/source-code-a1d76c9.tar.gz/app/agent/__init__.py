"""Agent orchestration boundary."""

